<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<header class="site-header">
  <div class="logo">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/logo.png" alt="Logo">
  </div>
  <nav class="main-nav">
    <?php wp_nav_menu(array('theme_location' => 'main-menu')); ?>
  </nav>
  <div class="contact-header">
    <a href="tel:+628118954320">📞 +628118954320</a>
  </div>
</header>
