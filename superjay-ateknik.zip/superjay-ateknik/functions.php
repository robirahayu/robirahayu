<?php
function superjaya_enqueue_assets() {
    wp_enqueue_style('main-style', get_template_difunction superjaya_register_menus() {
    register_nav_menu('main-menu', __('Main Menu'));
}
add_action('after_setup_theme', 'superjaya_register_menus');
rectory_uri() . '/assets/css/style.css');
    wp_enqueue_script('main-js', get_template_directory_uri() . '/assets/js/main.js', array(), false, true);
}
add_action('wp_enqueue_scripts', 'superjaya_enqueue_assets');
function superjaya_register_menus() {
    register_nav_menu('main-menu', __('Main Menu'));
}
add_action('after_setup_theme', 'superjaya_register_menus');
