<?php get_header(); ?>

<main class="main-content">
  <section class="hero">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/hero.jpg" alt="Hero Image">
    <h1>CV SUPER JAYA TEKNIK NURSE CALL SYSTEM</h1>
    <p>Produk LOKAL TERBAIK di Indonesia. Pengadaan - Instalasi - Konsultasi - Maintenance</p>
  </section>

  <section class="features">
    <div class="feature-item">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/img/fitur1.jpg" alt="">
      <h3>Keuntungan Menggunakan SJT</h3>
      <p>...</p>
    </div>
    <div class="feature-item">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/img/fitur2.jpg" alt="">
      <h3>Instalasi Lokal dan Kabel Mudah</h3>
      <p>...</p>
    </div>
    <div class="feature-item">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/img/fitur3.jpg" alt="">
      <h3>Cara Instalasi Sistem SJT</h3>
      <p>...</p>
    </div>
  </section>

  <section class="icons-section">
    <div class="icon-box">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icon-cepat.png" alt="">
      <p>Bekerja Cepat & Sigap</p>
    </div>
    <div class="icon-box">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icon-aman.png" alt="">
      <p>Keamanan Diperhatikan</p>
    </div>
    <div class="icon-box">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icon-profesional.png" alt="">
      <p>Profesional</p>
    </div>
  </section>
</main>

<?php get_footer(); ?>
