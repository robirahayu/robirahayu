// script.js

document.addEventListener("DOMContentLoaded", function() {
  // Smooth scroll for navigation links
  const navLinks = document.querySelectorAll("nav a[href^='#']");

  navLinks.forEach(link => {
    link.addEventListener("click", function(e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute("href"));
      if (target) {
        window.scrollTo({
          top: target.offsetTop - 60,
          behavior: "smooth"
        });
      }
    });
  });

  // Mobile nav toggle (optional future use)
  const navToggle = document.getElementById("nav-toggle");
  const navMenu = document.querySelector("nav ul");

  if (navToggle && navMenu) {
    navToggle.addEventListener("click", () => {
      navMenu.classList.toggle("active");
    });
  }

  // Scroll reveal effect
  const revealElements = document.querySelectorAll(".feature, .benefit, .intro, .hero");

  const revealOnScroll = () => {
    const triggerBottom = window.innerHeight * 0.85;
    revealElements.forEach(el => {
      const boxTop = el.getBoundingClientRect().top;
      if (boxTop < triggerBottom) {
        el.classList.add("show");
      } else {
        el.classList.remove("show");
      }
    });
  };

  window.addEventListener("scroll", revealOnScroll);
  revealOnScroll();
});

let currentIndex = 0;
const slides = document.querySelectorAll('.slide');

function showSlide(index) {
  slides.forEach((slide, i) => {
    slide.classList.remove('active');
    if (i === index) slide.classList.add('active');
  });
}

function moveSlide(step) {
  currentIndex = (currentIndex + step + slides.length) % slides.length;
  showSlide(currentIndex);
}

setInterval(() => {
  moveSlide(1);
}, 6000); // Slide otomatis setiap 6 detik
// Tambahan efek glow saat mouse mendekat
const button = document.querySelector('.whatsapp-float');

button.addEventListener('mouseenter', () => {
  button.style.boxShadow = '0 0 20px #25d366';
});

button.addEventListener('mouseleave', () => {
  button.style.boxShadow = '2px 2px 10px rgba(0,0,0,0.3)';
});

<button onclick="window.open('https://www.tiktok.com/@yusupm807', '_blank')">Tiktok</button>
<button onclick="window.open('https://Instagram.co.id/@CV.Superjayateknik target', '_blank')">Instragam</button>
<button onclick="window.open('https://www.facebook.com/cv.superjayateknik', '_blank')">facebook</button>
<button onclick="window.open('https://https://www.tokopedia.com/yspalkes', '_blank')">Tokopedia</button>
<button onclick="window.open('https://shopee.co.id/Yusupmunawar27', '_blank')">Shopee</button>




