<footer class="site-footer">
  <div class="footer-content">
    <div class="contact-info">
      <p>Email: cvsuperjayateknik@gmail.com</p>
      <p>Telp: +628118954320</p>
    </div>
    <div class="social-media">
      <p>Instagram: @cv_superjayateknik</p>
      <p>Shopee: shopee.co.id/yusupmunawar27</p>
    </div>
    <div class="about-footer">
      <p>Kami adalah penyedia produk Nurse Call terbaik di Indonesia.</p>
    </div>
  </div>
  <p class="copyright">© <?php echo date("Y"); ?> CvSuperJayaTeknik.com</p>
</footer>

<?php wp_footer(); ?>
</body>
</html>
