<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php bloginfo('name'); ?></title>
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<header>
  <div class="logo">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icon.png" alt="Logo CV Super Jaya Teknik">
    <div id="contact" class="text cv"><h1>CV SUPER JAYA TEKNIK</h1></div>
  </div>
  <nav>
    <ul>
      <li><a href="#about">ABOUT</a></li>
      <li><a href="#product">PRODUCT</a></li>
      <li><a href="#solution">SOLUTION AND TESTIMONI</a></li>
      <li><a href="#contact">HUBUNGI KAMI</a></li>
    </ul>
  </nav>
</header>
