<?php get_header(); ?>

<main class="page-content">
  <?php
  if (have_posts()) :
    while (have_posts()) : the_post(); ?>
      <article class="page">
        <h1><?php the_title(); ?></h1>
        <div class="content">
          <?php the_content(); ?>
        </div>
      </article>
    <?php endwhile;
  else : ?>
    <p>Halaman tidak ditemukan.</p>
  <?php endif; ?>
</main>

<?php get_footer(); ?>
