<?php
function sjt_enqueue_assets() {
    // CSS
    wp_enqueue_style('style-css', get_template_directory_uri() . '/assets/css/style.css');
    wp_enqueue_style('app-css', get_template_directory_uri() . '/assets/css/app.css');
    wp_enqueue_style('index-css', get_template_directory_uri() . '/assets/css/index.css');

    // JS
    wp_enqueue_script('main-js', get_template_directory_uri() . '/assets/js/script.js', array(), null, true);
}
add_action('wp_enqueue_scripts', 'sjt_enqueue_assets');
