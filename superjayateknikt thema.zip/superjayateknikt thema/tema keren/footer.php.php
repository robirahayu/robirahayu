<footer>
  <div id="contact" class="contact-info">
    <h4>Hubungi Kami</h4>
    <p>Email: <a href="mailto:superjayateknik@gmail.com">superjayateknik@gmail.com</a></p>
    <p>Telepon: <a href="tel:+628118954320">+62 811 8954 320</a></p>
  </div>

  <div class="social-media">
    <h4>Social Media</h4>
    <ul>
      <li><a href="https://www.tiktok.com/@yusupm807" target="_blank">Tiktok</a></li>
      <li><a href="https://instagram.com/cv.superjayateknik" target="_blank">Instagram</a></li>
      <li><a href="https://facebook.com/cv.superjayateknik" target="_blank">Facebook</a></li>
    </ul>
  </div>

  <div class="about-us">
    <h4>Belanja</h4>
    <ul>
      <li><a href="https://www.tokopedia.com/yspalkes" target="_blank">Tokopedia</a></li>
      <li><a href="https://shopee.co.id/Yusupmunawar27" target="_blank">Shopee</a></li>
    </ul>
  </div>

  <!-- Tombol WhatsApp -->
  <a href="https://wa.me/6281234567890" class="whatsapp-float" target="_blank" title="Chat via WhatsApp">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/whatsap.png" alt="WhatsApp">
  </a>

  <p class="copyright">&copy; <?php echo date('Y'); ?> CvSuperjayaTeknik.com</p>
</footer>

<?php wp_footer(); ?>
</body>
</html>
